// soc05h-cc-Jessica-Sanchez
// ready to upload 8/16/2018

/*
Task: 
	[x] Calculate the size of a continent you are standing on in your 11 x 11 world in Civilization III.

Bonuses for:
	[x] calculate continent size for all continents in the world
	[x] random world generator
	[x] fastest program
	[ ] benchmarking
	[x] extension of the problem to n x n size world
*/

function world_generator(n) {
	world = [] 
	w = []
	x = 0
	// 1 is Land, 0 is Water
	for (var row = 0; row < n; row++) { //row
		
		for (var col = 0; col < n; col++){
			x = parseInt(Math.random()*2)
			w.push(x)
		}			
		
		world.push(w)
		w=[]

	}

	return world
}

function world_copy(world) {
	wcopy = []
	for (var row = 0; row < world.length; row++){
		line = []
		for (var col = 0; col < world.length; col++){
			line.push(world[row][col])
		}
		wcopy.push(line)
	}
	return wcopy
}

function print_world(world) {

	for (var i = 0; i<world.length; i++)
		console.log(world[i])
}

function land_counter (world, row, col) {
	if (world[row][col] != 1) {return 0}

	world[row][col] = 'x'
	count = 1


	//upper levels:
	if (row != 0) { 

		if (col != 0 && world[row-1][col-1] == 1) {//left-up
			count = count + land_counter(world, row-1, col-1)
		}

		if (world[row-1][col] == 1) {//up
			count = count + land_counter(world, row-1 , col)
		}	

		if (col != world.length-1 && world[row-1][col+1] == 1) {//right-up
			count = count + land_counter(world, row-1, col+1)
		}
	}

	//sides

	if ( col != 0 && world[row][col-1] == 1 ) {// left
		count = count + land_counter(world, row, col-1)
	}

	if (col != world.length-1 && world[row][col+1] == 1){//right
		count = count + land_counter(world, row, col+1)
	}

	// down levels
	if (row != world.length-1) {
		if (col != 0 && world[row+1][col-1] == 1){//down left
			count = count + land_counter(world, row+1, col-1)
		}

		if (world[row+1][col] == 1){//down
			count = count + land_counter(world, row+1, col)
		}
		
		if (col != world.length-1 && world[row+1][col+1] == 1){//down right
			count = count + land_counter(world, row+1, col+1)
		}

	}

	return count
}

// Random World
// GET SIZE
n = 0
while ( !Number.isInteger(parseInt(n)) || n== '' || n <= 3 ) {
	n = prompt('Enter the size of your world (n), number should be integer and larger or equal to 3: ')
}

world1 = world_generator(n)

// GET LOCATION
print_world(world1)
row = -1
col = -1 
while ( !Number.isInteger(parseInt(row))|| !Number.isInteger(parseInt(col)) || 
		row > n-1 || col > n-1 || row < 0 || col < 0 ) {
	
	row = prompt ("Please enter your location from 0 to "+ (n-1) + "\nrow: ")
	col = prompt ("row: "+ row + ", col: ")
}

row = parseInt(row)
col = parseInt(col)


//// predefined world  11 x 11
// world1 = [
// 		[1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1],
// 		[1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0],
// 		[0, 1, 1, 0, 1, 1, 0, 0, 0, 1, 0],
// 		[1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1],
// 		[1, 0, 1, 0, 1, 1, 1, 0, 1, 0, 0],
// 		[0, 1, 0, 0, 1, 1, 0, 0, 0, 1, 0],
// 		[1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1],
// 		[0, 0, 1, 0, 0, 1, 0, 1, 0, 0, 0],
// 		[0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0],
// 		[0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1],
// 		[0, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1]
// 		]
// row = 9
// col = 9


world2 = world_copy(world1)
count1 = land_counter(world2, row, col)

// console.log("world1")
// print_world(world1)
console.log("Your location is row:", row,", col:", col," and the size of this Land is ",count1," boxes.")
if (count1 == 0){
	console.log("You are standing in the sea! Glu Glu Glu....")
}
console.log("world2")
print_world(world2)


function other_continents(world2){
	continents = []

	for (var row = 0; row < world2.length; row++){
		for (var col = 0; col < world2.length; col++){
			if (world2[row][col] == 1){
				continents.push(land_counter(world2, row, col))
				// console.log("x")

			}
		}
	}

	return continents

}



continents = other_continents(world2)
// count = land_counter(world2, row, col) // count change when running other_continents

// console.log(continents.length, continents)
if (count1 == 0 && continents.length > 0){ //standing in water and exist other continents
	console.log("In total there are " + (continents.length) + " contintents in this world. " )
} 

else if (count1 > 0){// standing in Land
	if (continents.length > 0) { // standing in Land and exist other continents
		console.log("In total there are " + (continents.length + 1) + " contintents in this world including yours. " )
		if (count1 > Math.max(...continents)){ // if standing in the largest
			console.log("Your continent is the largest in the world")
		} 
		else  { //
			console.log("There is another continent larger than yours, with "+ Math.max(...continents)+ " boxes.")
		}
	}	
	if (continents.length == 0) {//standing in land and no other continents
		console.log("There are no other continents in this world.")
	}	
}

if (continents.length>0){
	console.log("This is the size of the other continents: ", continents)
}




