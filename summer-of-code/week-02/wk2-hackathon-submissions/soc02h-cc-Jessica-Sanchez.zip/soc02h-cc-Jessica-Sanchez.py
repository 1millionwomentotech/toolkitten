##C:\Users\Public\Online_Courses\SOC\WK2
##4draftWK2_H.py
from random import randint

def intro():
	print('\n**** WELCOME TO BOGGLE ****\n')
	print('After the board is shaken, you will have 3 minutes to write down all words you can see on the board.')
	print('\nPoints are given in the following way:')
	print('\t* 1 and 2 letter words = 0 points \n\t* 3 letter words = 1 point \n\t* 4 letter words = 2 points \n\t* 5 letter words = 3 points')
	print('\t*and so on...')
	print('\nThe longest possible word 16 letter word = 14 points')
	print('\nWhen you build a word, you can only use one letter once: in other words if you travel along the board \nand you used a letter, you cannot use it again for the same word, however, you CAN use it for a new word.')
		
def get_size():
	n=int(input('\nSelect the size of the board from 3 to 5: '))
	if n<3 or n>5:
		get_size()
	else:
		return n

def dice(n):
	#dices (1-9) repeated to fill in the missing dices for 5x5 version (17-25)
	dices=(
		'aaeegn','elrtty','aoottw','abbjoo','ehrtvw',
		'cimotu','distty','eiosst','delrvy','achops',
		'himnqu','eeinsu','eeghnw','affkps','hlnnrz',
		'deilrx',
		'aaeegn','elrtty','aoottw','abbjoo','ehrtvw',
		'cimotu','distty','eiosst','delrvy')
	return dices[n]

def create_board(n):
	#board nxn
	dice_n=0
	board=[]
	row=[]
	
	for i in range (n):#build rows
		#build columns
		for j in range (n):
			r=randint(0,5)
			d=dice(dice_n)
			row.append(d[r])
			dice_n+=1
		board.append(row)
		row=[]
	return board

def printBoard(board):
	print('\n')
	for x in board:
		print(" ".join(map(str, x)))
	print('\n')

def singleLetters():##reduce board to a string of sorted letters
	cleanBoard=[]
	lettersinboard=''
	for row in range (n):
		for col in range (n):
			cleanBoard.append(board[row][col])
	#print('sorted cleanboard:'+ str(sorted(cleanBoard)))
	for c in sorted(cleanBoard):
		lettersinboard+=c
	return lettersinboard

def choose_dict():
	d=0
	print('\nWhich dictionary would you like to use:')
	print('\nOption1: Scrabble_Bot.     Option2: Words_Alpha.')
	while d<1 or d>2:		
		d=int(input('\n      Enter 1 or 2: '))
	result =d

def get_dictionary(d):
	#https://raw.githubusercontent.com/dwyl/english-words/master/words_alpha.txt
	option1 = "dictionary.txt"
	option2 = "words_alpha.txt"
	if d == 1 :
		filename=option1
	else :
		filename=option2
	file = open(filename,"r")
	raw = file.read()
	#print(raw)
	return raw

def dictonary_to_dict():
	s=dictionary
	#print(s)
	ws={}#list of words that only contains the letters from the board
	end=0
	start=0
	while end<len(s):
		if '\n' in s:
			end=s.index('\n')
		else:
			end=len(s)
		if check_if_contains(s[start:end]):
			if len(s[start:end])<=2:
				score=0
			else:
				score=len(s[start:end])-2
			ws[s[start:end]]=score
		s=s[end+1:]
	#print(len(s))
	#print(len(list1))
	return ws

def check_if_contains(s):
	c=False
	boardcopy=board_letters
	for i in range (len(s)):
		if s[i] in boardcopy:
			l=s[i]
			index=boardcopy.index(l)
			c=True
			#delete letter from string:
			if len(boardcopy)==1:
				return c
			elif index==0:
				boardcopy=boardcopy[1:]
			elif index==len(boardcopy)-1:
				boardcopy=boardcopy[:len(boardcopy)-1]
			else:
				boardcopy=boardcopy[:index]+boardcopy[index+1:]
		else:
			c=False
			return c
	return c

def print_w_s(d):	
	for w in d:
		if w!='SCORE' or w!='WORDS':
			print(w+': '+str(d[w]))

def get_user_list():
	user_words={}
	print('\nThis is your board: ')
	printBoard(board)
	print('You have 3 minutes to enter your words, enter one word at a time and press enter to add a new word. \nWhen finished press Enter.')
	n=' '
	score=0
	words=[]
	while n!='':
		n=input('>')
		if n!='':
			if n.lower() not in words:
				if (n.lower() in list_of_words.keys()):
					user_words[n.lower()]=list_of_words[n.lower()]
					words.append(n.lower())
					score+=list_of_words[n.lower()]
				else:
					user_words[n.lower()]='not applicable'
	user_words['SCORE']=score
	user_words['WORDS']=sorted(words)
	return user_words

#Step 1: Intro get input from user (board size)
intro()
n=get_size()

#Step 2: Choose Dictionary
d=choose_dict()
dictionary=get_dictionary(d).lower() ##user better capslock
#ready?
#Step3: BACKGROUND PROCESS, takes up to 1.5 minutes
#convert dictionary.txt into a dictionary with word and score, including only the letters from board

#Build Board
board = create_board(n)
board_letters=singleLetters()

#Build Dictionary
print('\nDictionary is loading, this could take up to 5 minutes, be pacient...')
list_of_words=dictonary_to_dict()

print('Dictionary Loaded... ')
#print_w_s(list_of_words)

#Ready to play!! 
print(input('\nAre you ready? press Enter to Shake the Board'))
user_list=get_user_list()
print('\nYour Final score is: '+str(user_list['SCORE']))
print('\nScore per word: \n')
print_w_s(user_list)
	
def boggle_result():
	result={}
	result["score"]=user_list['SCORE']
	result["words"]=user_list['WORDS']
	return result

print(boggle_result())