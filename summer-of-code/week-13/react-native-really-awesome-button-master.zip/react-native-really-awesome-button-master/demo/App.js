import React from 'react';
import {
  StyleSheet,
  View,
  ScrollView,
} from 'react-native';
import { RootStack } from './components';


export default class Demo extends React.Component {
  render() {
    return <RootStack />;
  }
}
